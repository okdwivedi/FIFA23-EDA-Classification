# FIFA23-EDA-Classification
Performing Exploratory Data Analysis and Classification of Player's Positions in our FIFA Dataset
